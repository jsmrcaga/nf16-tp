
#include <stdio.h>
#include <stdlib.h>

#include "stdlib.h" //pour le malloc
#include "string.h"

#include "outils.h"
#include "arbre.h"
#include "liste.h"


#define TAILLE_MAX 100


ArbreBR * arbre;


void main(){

	printMenu ();

}


